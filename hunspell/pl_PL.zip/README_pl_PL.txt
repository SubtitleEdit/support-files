English:
========

This dictionary for spell-checking Polish texts is licensed under
GPL 2, LGPL 2.1, MPL (Mozilla Public License) 1.1, Apache 2.0 and
Creative Commons Attribution 4.0 International

This version of the dictionary was generated on 2020-09-03

https://sjp.pl/slownik/en/

Contact: sjpslownik@gmail.com


Polski:
=======

Slownik do sprawdzania pisowni jest udostepniany na licencjach
GPL 2, LGPL 2.1, MPL (Mozilla Public License) 1.1, Apache 2.0 i
Creative Commons Attribution 4.0 International

Data utworzenia tej wersji: 2020-09-03

https://sjp.pl

Contact: sjpslownik@gmail.com

